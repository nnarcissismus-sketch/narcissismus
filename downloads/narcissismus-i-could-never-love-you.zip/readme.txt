replace this file with the real release (zip with tracks)
